write("", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex",append=FALSE)
resultDirectory<-"./MetaheuristicsStudy/data"
latexHeader <- function() {
  write("\\documentclass{article}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\title{StandardStudy}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\usepackage{amssymb}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\author{A.J.Nebro}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\begin{document}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\maketitle", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\section{Tables}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
}

latexTableHeader <- function(problem, tabularString, latexTableFirstLine) {
  write("\\begin{table}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\caption{", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write(problem, "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write(".SPREAD.}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)

  write("\\label{Table:", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write(problem, "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write(".SPREAD.}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)

  write("\\centering", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\begin{scriptsize}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\begin{tabular}{", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write(tabularString, "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write(latexTableFirstLine, "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\hline ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
}

printTableLine <- function(indicator, algorithm1, algorithm2, i, j, problem) { 
  file1<-paste(resultDirectory, algorithm1, sep="/")
  file1<-paste(file1, problem, sep="/")
  file1<-paste(file1, indicator, sep="/")
  data1<-scan(file1)
  file2<-paste(resultDirectory, algorithm2, sep="/")
  file2<-paste(file2, problem, sep="/")
  file2<-paste(file2, indicator, sep="/")
  data2<-scan(file2)
  if (i == j) {
    write("-- ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  }
  else if (i < j) {
    if (is.finite(wilcox.test(data1, data2)$p.value) & wilcox.test(data1, data2)$p.value <= 0.05) {
      if (median(data1) <= median(data2)) {
        write("$\\blacktriangle$", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
      }
      else {
        write("$\\triangledown$", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE) 
      }
    }
    else {
      write("--", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE) 
    }
  }
  else {
    write(" ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  }
}

latexTableTail <- function() { 
  write("\\hline", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\end{tabular}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\end{scriptsize}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
  write("\\end{table}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
}

latexTail <- function() { 
  write("\\end{document}", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
}

### START OF SCRIPT 
# Constants
problemList <-c("NRPClassic") 
algorithmList <-c("NSGAII", "TS", "ACO", "SA", "RS") 
tabularString <-c("lcccc") 
latexTableFirstLine <-c("\\hline  & TS & ACO & SA & RS\\\\ ") 
indicator<-"SPREAD"

 # Step 1.  Writes the latex header
latexHeader()
tabularString <-c("| l | p{0.15cm } | p{0.15cm } | p{0.15cm } | p{0.15cm } | ") 

latexTableFirstLine <-c("\\hline \\multicolumn{1}{|c|}{} & \\multicolumn{1}{c|}{TS} & \\multicolumn{1}{c|}{ACO} & \\multicolumn{1}{c|}{SA} & \\multicolumn{1}{c|}{RS} \\\\") 

# Step 3. Problem loop 
latexTableHeader("NRPClassic ", tabularString, latexTableFirstLine)

indx = 0
for (i in algorithmList) {
  if (i != "RS") {
    write(i , "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
    write(" & ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)

    jndx = 0
    for (j in algorithmList) {
      for (problem in problemList) {
        if (jndx != 0) {
          if (i != j) {
            printTableLine(indicator, i, j, indx, jndx, problem)
          }
          else {
            write("  ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
          } 
          if (problem == "NRPClassic") {
            if (j == "RS") {
              write(" \\\\ ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
            } 
            else {
              write(" & ", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
            }
          }
     else {
    write("&", "./MetaheuristicsStudy/R/SPREAD.Wilcoxon.tex", append=TRUE)
     }
        }
      }
      jndx = jndx + 1
    }
    indx = indx + 1
  }
} # for algorithm

  latexTableTail()

#Step 3. Writes the end of latex file 
latexTail()

