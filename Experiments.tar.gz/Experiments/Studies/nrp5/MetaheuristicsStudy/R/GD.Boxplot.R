postscript("GD.Boxplot.eps", horizontal=FALSE, onefile=FALSE, height=8, width=12, pointsize=10)
resultDirectory<-"../data"
qIndicator <- function(indicator, problem)
{
fileNSGAII<-paste(resultDirectory, "NSGAII", sep="/")
fileNSGAII<-paste(fileNSGAII, problem, sep="/")
fileNSGAII<-paste(fileNSGAII, indicator, sep="/")
NSGAII<-scan(fileNSGAII)

fileTS<-paste(resultDirectory, "TS", sep="/")
fileTS<-paste(fileTS, problem, sep="/")
fileTS<-paste(fileTS, indicator, sep="/")
TS<-scan(fileTS)

fileACO<-paste(resultDirectory, "ACO", sep="/")
fileACO<-paste(fileACO, problem, sep="/")
fileACO<-paste(fileACO, indicator, sep="/")
ACO<-scan(fileACO)

fileSA<-paste(resultDirectory, "SA", sep="/")
fileSA<-paste(fileSA, problem, sep="/")
fileSA<-paste(fileSA, indicator, sep="/")
SA<-scan(fileSA)

fileRS<-paste(resultDirectory, "RS", sep="/")
fileRS<-paste(fileRS, problem, sep="/")
fileRS<-paste(fileRS, indicator, sep="/")
RS<-scan(fileRS)

algs<-c("NSGAII","TS","ACO","SA","RS")
boxplot(NSGAII,TS,ACO,SA,RS,names=algs, notch = TRUE)
titulo <-paste(indicator, problem, sep=":")
title(main=titulo)
}
par(mfrow=c(1,2))
indicator<-"GD"
qIndicator(indicator, "NRPClassic")
